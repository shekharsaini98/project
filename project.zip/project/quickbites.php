<html>
    <head>
        <link rel="stylesheet" href="stylesheet.css">
    </head>
    <body>
        <div class="container">
            <nav>
                <ul>
                    <li> <img src="coffeemoon.png" class="logo"> </li>
                    <li> <a href="index.php">HOME</a> </li>
                    <li> <a href="reservation.php">RESERVATION</a> </li>
                    <li> <a href="blog.php">BLOG</a> </li>
                    <li> <a href="shop.php">SHOP</a> </li>
                    <li> <a href="contact.php">CONTACT</a> </li>
                    <input type="search"class="search" name="search" placeholder="Search..">
                </ul>
            </nav>
        </div>
        <div class="info">You can order our products by contacts</div> 
        <div class="shophead">
            <span id="categories">CATEGORIES</span>
            <span id="bests">QUICK BITES</span>
        </div> 
        <div class="shoplist">
            <ul>
                <li><a href="shop.php">WHAT'S NEW</a></li>
                <li><a href="coffeepowder.php">COFFEE POWDERS</a></li>
                <li><a href="tea.php">TEA</a></li>
                <li><a href="quickbites.php">QUICK BITES</a></li>
                <li><a href="cakebites.php">CAKE BITES</a></li>
            </ul>    
        </div>
        <div id="row">
            <div class="firstrow1">
                <label for="fsb">Mints (Pack of 10)</label><br>
                <a href="buy/Mints (Pack of 10).php"><img src="quickbites/ccd-oxy-mint.jpg" id="fsb" alt="Mints (Pack of 10)" title="Mints (Pack of 10)"></a>
                <p>Rs.200/-</p>
            </div>
            <div class="firstrow2">
                <label for="hsg">JOIE Hazelnut Bar (pack of 2)</label><br>
                <a href="buy/JOIE Hazelnut Bar (pack of 2).php"><img src="quickbites/joie_hazelnut.jpg" id="hsg" alt="JOIE Hazelnut Bar (pack of 2)" title="JOIE Hazelnut Bar (pack of 2)"></a>
                <p>Rs.200/-</p>
            </div> 
            <div class="firstrow3">   
                <label for="mti">Double Choco Chip Cookies (Pack of 2)</label><br>
                <a href="buy/Double Choco Chip Cookies (Pack of 2).php"><img src="quickbites/dcc_cookies.jpg" id="mti" alt="Double Choco Chip Cookies(Pack of 2)" title="Double Choco Chip Cookies(Pack of 2)"></a>
                <p>Rs.300/-</p>
            </div>
            <div class="secondrow1">    
                <label for="orw">Honey & Oat Meal Cookies (Pack of 2)</label><br>
                <a href="buy/Honey Oat Meal Cookies (Pack of 2).php"><img src="quickbites/hno_cookies.jpg" id="orw" alt="Honey & Oat Meal Cookies (Pack of 2)" title="Honey & Oat Meal Cookies (Pack of 2)"></a>
                <p>Rs.300/-</p>
            </div>  
        </div> 
    </body>
    <footer>
    <br>
    <br>
    <br>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="reservation.php">Reservation</a></td>
                <td><a href="shop.php">What's New</a></td>
                <td><a href="coffeepowder.php">Coffee Powder</a></td>
                <td><a href="ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href="delete.php">Cancel Reservation</a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="quickbites.php">Quick Bites</a></td>
                <td><a href="Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href="update.php">Update Reservation</a></td>
                <td><a href=""></a></td>
                <td><a href="tea.php">TEA's</a></td>
                <td><a href="Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="faq.php">FAQ</a></td>
                <td><a href="contact.php">Contact Us</a></td>
            </tr>
        </table> 
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>    
    </footer>
</html>        