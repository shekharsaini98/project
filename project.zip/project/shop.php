<html>
    <head>
        <link rel="stylesheet" href="stylesheet.css">
    </head>
    <body>
        <div class="container">
            <nav>
                <ul>
                    <li> <img src="coffeemoon.png" class="logo"> </li>
                    <li> <a href="index.php">HOME</a> </li>
                    <li> <a href="reservation.php">RESERVATION</a> </li>
                    <li> <a href="blog.php">BLOG</a> </li>
                    <li> <a href="shop.php">SHOP</a> </li>
                    <li> <a href="contact.php">CONTACT</a> </li>
                    <input type="search"class="search" name="search" placeholder="Search..">
                </ul>
            </nav>
        </div>
        <div class="info">You can also order our products by contacts</div> 
        <div class="shophead">
            <span id="categories">CATEGORIES</span>
            <span id="bests">WHAT'S NEW</span>
        </div> 
        <div class="shoplist">
            <ul>
                <li><a href="shop.php">WHAT'S NEW</a></li>
                <li><a href="coffeepowder.php">COFFEE POWDERS</a></li>
                <li><a href="tea.php">TEA</a></li>
                <li><a href="quickbites.php">QUICK BITES</a></li>
                <li><a href="cakebites.php">CAKE BITES</a></li>
            </ul>    
        </div> 
        <div id="row">
            <div class="firstrow1">
                <label for="fsb"><p align="center"class="black">Fruit Infuser Bottle</p></label><br>
                <a href="buy/Fruit Infuser Bottle.php"><img src="whatsnew/fruit_infuser_bottle.jpg" id="fsb" alt="Fruit Infuser Bottle" title="Fruit Infuser Bottle"></a>
                <p align="center">Rs.588/-</p>
            </div>
            <div class="firstrow2">
                <label for="hsg"><p align="center"class="black">Heart Shaped Glass</p></label><br>
                <a href="buy/Heart Shaped Glass.php"><img src="whatsnew/heart_shaped_glass.jpg" id="hsg" alt="Heart Shaped Glass" title="Heart Shaped Glass"></a>
                <p align="center">Rs.706/-</p>
            </div> 
            <div class="firstrow3">   
                <label for="mti"><p align="center"class="black">Mr. Tea Infuser</p></label><br>
                <a href="buy/Mr. Tea Infuser.php"><img src="whatsnew/mr tea infuser.jpg" id="mti" alt="Mr. Tea Infuser" title="Mr. Tea Infuser"></a>
                <p align="center">Rs.334/-</p>
            </div>
            <div class="secondrow1">    
                <label for="orw"><p align="center"class="black">Orion Automatic Machine</p></label><br>
                <a href="buy/Orion Automatic Machine.php"><img src="whatsnew/orion_red-web.jpg" id="orw" alt="Orion Automatic Machine" title="Orion Automatic Machine"></a>
                <p align="center">Rs.6499/-</p>
            </div>  
            <div class="secondrow2">  
                <label for="swm"><p align="center"class="black">Stars Wars Mugs</p></label><br>
                <a href="buy/Stars Wars Mugs.php"><img src="whatsnew/star_wars_mug.jpg" id="swm" alt="Stars Wars Mugs" title="Stars Wars Mugs"></a>
                <p align="center">Rs.1296/-</p>
            </div>   
            <div class="secondrow3"> 
                <label for="tmnm"><p align="center"class="black">Travel Mug Marine</p></label><br>
                <a href="buy/Travel Mug Marine.php"><img src="whatsnew/travel_mug_new marine.jpg" id="tmnm" alt="Travel Mug Marine" title="Travel Mug Marine"></a>
                <p align="center">Rs.799/-</p>
            </div>    
        </div>    
    </body>
    <footer>
    <br>
    <br>
    <br>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="reservation.php">Reservation</a></td>
                <td><a href="shop.php">What's New</a></td>
                <td><a href="coffeepowder.php">Coffee Powder</a></td>
                <td><a href="ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href="delete.php">Cancel Reservation</a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="quickbites.php">Quick Bites</a></td>
                <td><a href="Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href="update.php">Update Reservation</a></td>
                <td><a href=""></a></td>
                <td><a href="tea.php">TEA's</a></td>
                <td><a href="Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="faq.php">FAQ</a></td>
                <td><a href="contact.php">Contact Us</a></td>
            </tr>
        </table> 
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>    
    </footer>
</html>        