<html>
    <head>
        <link rel="stylesheet" href="stylesheet.css">
    </head>
    <body>
        <div class="b5">
            <div class="container">
                <nav>
                    <ul>
                        <li><img src="coffeemoon.png" class="logo"> </li>
                        <li> <a href="index.php">HOME</a> </li>
                        <li> <a href="reservation.php">RESERVATION</a> </li>
                        <li> <a href="blog.php">BLOG</a> </li>
                        <li> <a href="shop.php">SHOP</a> </li>
                        <li> <a href="contact.php">CONTACT</a> </li>
                        <input type="search" class="search" name="search" placeholder="Search..">
                    </ul>
                </nav>
            </div><br>
                <div class="contact">
                    <div class="time"><b> Open<b><br>Time <br></div>
                    <b> Monday-Friday &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Saturday-Sunday<br>
                    7AM-11AM (BREAKFAST) &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 8AM-1PM (BRUNCH)<br>
                    1PM-10PM (LUNCH/DINNER) &nbsp &nbsp &nbsp 1PM-9PM (LUNCH/DINNER)<br><hr>
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Contact:+91 9650855090,9015555141<br>
                    &nbsp &nbsp &nbsp &nbsp Address:307-A New Friends Colony,New Delhi-110014<br>
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Email:coffeemoon@gmail.com<b>
                </div>        
        </div>
    </body>
    <br>
    <footer>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="reservation.php">Reservation</a></td>
                <td><a href="shop.php">What's New</a></td>
                <td><a href="coffeepowder.php">Coffee Powder</a></td>
                <td><a href="ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href=""></a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="quickbites.php">Quick Bites</a></td>
                <td><a href="Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="tea.php">TEA's</a></td>
                <td><a href="Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="faq.php">FAQ</a></td>
                <td><a href="contact.php">Contact Us</a></td>
            </tr>
        </table>
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>     
    </footer>
</html>    