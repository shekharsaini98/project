<?php
$url="Localhost";
$dbpass="";
$dbuname="root";
$dbname="coffee";
$con=mysql_connect($url,$dbuname,$dbpass) or die(mysql_error());
mysql_select_db($dbname,$con) or die(mysql_error());
?>