<?php
    $name=$number=$address=$email=$state=$city=$zipcode=$status="";
    $namer=$numberr=$addressr=$emailr=$stater=$cityr=$zipcoder="";
    if(isset($_GET['submit'])) 
        { 
            $name=$_GET['name'];
            $number=$_GET['number'];
            $address=$_GET['address'];
            $email=$_GET['email'];
            $state=$_GET['state'];
            $city=$_GET['city'];
            $zipcode=$_GET['zipcode'];
            if(empty($name))
                $namer="Enter name<br>";
            if(empty($number))
                $numberr="Enter number<br>";
            if(empty($address))
                $addressr="Enter address<br>";
            if(empty($email))
                $emailr="Enter Email <br>";
            elseif(!FILTER_VAR($email,FILTER_VALIDATE_EMAIL))
                $emailr="INVALID EMAIL <br>";
            if(empty($state))
                $stater="Enter state<br>";
            if(empty($city))
                $cityr="Enter city<br>";
            if(empty($zipcode))
                $zipcoder="Enter zipcode<br>";
            if($namer=="" && $numberr=="" && $addressr=="" && $emailr=="" && $stater=="" && $cityr=="" && $zipcoder=="")
                {   
                    include("dbproduct.php");
                    $query="insert into product(name,number,address,email,state,city,zipcode)values('".$name."','".$number."','".$address."','".$email."','".$state."','".$city."','".$zipcode."')";
                    $result=mysql_query($query) or die(mysql_error());
                    {
                        if($result>0)
                        $status="Hello $name <br><br> Your product will be deliver within one week<br><br>!!! HAVE A NICE DAY !!! ";
                        else
                        $status="Table reservation failed";
                    }
                }        
        }
?>
<html>
    <head>
        <link rel="stylesheet" href="../stylesheet.css">
    </head>
    <body>
        <form>
        <div class="container">
            <nav>
                <ul>
                    <li> <img src="../coffeemoon.png" class="logo"> </li>
                    <li> <a href="../index.php">HOME</a> </li>
                    <li> <a href="../reservation.php">RESERVATION</a> </li>
                    <li> <a href="../blog.php">BLOG</a> </li>
                    <li> <a href="../shop.php">SHOP</a> </li>
                    <li> <a href="../contact.php">CONTACT</a> </li>
                    <input type="search"class="search" name="search" placeholder="Search..">
                </ul>
            </nav>
        </div>
        <br><br><br><br><br><br><br><br>
        <div class="purchase">
            <img src="buypic/orion_red-web.jpg" class="buypic" alt="COFFEE MAKER-ORION RED" title="COFFEE MAKER-ORION RED">
            <div class="buydetails">
               <div class="buyhead">COFFEE MAKER-ORION RED</div>
                <div class="buycontent">With a coffee maker like Orion, bring the artistry of a barista into your home and office. Position your cup, drop in a capsule and in just moments - a cup of perfectly brewed coffee awaits.</div>
                <div class="buyprice">PRICE :- 6499.00</div>
                <div class="Shipping">Shipping Details</div>
                <div class="">
                    <label id="name">Name: &nbsp &nbsp&nbsp </label>
                    <input type="text" placeholder="Enter full name" name="name" class="bres" value="<?php echo $name?>"><span class="errorr"><?php echo $namer?></span>
                    <label id="number">Phone:&nbsp &nbsp </label>
                    <input type="number" placeholder="Enter only 10 digits" name="number" class="bres" value="<?php echo $number?>"><span class="errorr"><?php echo $numberr?></span><br>
                    <label id="address">Address:</label>
                    <input type="text" placeholder="Enter full address"  name="address" class="bres" value="<?php echo $address?>" size="63"><span class="errorr"><?php echo $addressr?></span><br>
                    <label id="email">Email: &nbsp &nbsp&nbsp</label>
                    <input type="email" name="email" class="bres" value="<?php echo $email?>"><span class="errorr"><?php echo $emailr?></span>
                    <label id="state">State: &nbsp &nbsp &nbsp</label>
                    <input type="text" name="state" class="bres" value="<?php echo $state?>"><span class="errorr"><?php echo $stater?></span>
                    <label id="city">City: &nbsp &nbsp &nbsp &nbsp</label>
                    <input type="text" name="city" class="bres" value="<?php echo $city?>"><span class="errorr"><?php echo $cityr?></span>
                    <label id="zipcode">Zipcode: &nbsp</label>
                    <input type="number" placeholder="zip/postal code"  name="zipcode" class="bres" value="<?php echo $zipcode?>"><span class="errorr"><?php echo $zipcoder?></span><br>
                    <input type="submit" name="submit" class="bresv" value="Buy Now" ><br>
                    <?php echo"$status";?>
                </div>    
            </div>   
        </div>
        </form>
    </body>
    <footer>
    <br>
    <br>
    <br>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="../reservation.php">Reservation</a></td>
                <td><a href="../shop.php">What's New</a></td>
                <td><a href="../coffeepowder.php">Coffee Powder</a></td>
                <td><a href="../ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href="../delete.php">Cancel Reservation</a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="../quickbites.php">Quick Bites</a></td>
                <td><a href="../Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href="../update.php">Update Reservation</a></td>
                <td><a href=""></a></td>
                <td><a href="../tea.php">TEA's</a></td>
                <td><a href="../Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="../faq.php">FAQ</a></td>
                <td><a href="../contact.php">Contact Us</a></td>
            </tr>
        </table> 
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>    
    </footer>
</html>  