<html>
    <head>
        <link rel="stylesheet" href="stylesheet.css">
        
    </head>
    <body>
        <div class="container">
            <nav>
                <ul>
                    <li> <img src="coffeemoon.png" class="logo"> </li>
                    <li> <a href="index.php">HOME</a> </li>
                    <li> <a href="reservation.php">RESERVATION</a> </li>
                    <li> <a href="blog.php">BLOG</a> </li>
                    <li> <a href="shop.php">SHOP</a> </li>
                    <li> <a href="contact.php">CONTACT</a> </li>
                    <input type="search"class="search" name="search" placeholder="Search..">
                </ul>
            </nav>
        </div>
        <br>
        <div class="faq">
        <h3 align="center">FAQ</h3>
        <p class="red">What are the shipping charges?</p>
        <p class="black">Presently the customer does not have to pay shipping charges for any delivery from Coffee Moon.</p>
        <p class="red">Can I return a product if It does not work or received broken?</p>
        <p class="black">Yes you certainly can return a product back to us provided you have taken care that you have not tampered with it or mishandled it. We provide you with a complete guarantee on the product(s) sent by us. The customer may send the product back to CCD in case it is found to be defective, or unworthy of use.</p>
        <p class="red">What payment methods do you offer? </p>
        <p class="black">You may choose to pay via internet banking, debit card and credit card (Visa and Master). All transactions online are made over a secure payment gateway that ensures that your transaction details remain safe and secure and is never compromised at any point of time.  </p> 
        <p class="red">How long does delivery take?  </p>
        <p class="black">Delivery of the product(s) takes about 5-7 working days. </p>
        <p class="red">How can I be assured of the product quality?  </p>
        <p class="black">At Cafe Coffee Day's, we take great pride in delivering products that is of a high standard and never compromise on quality. In the unlikely event that something arrives at your doorstep broken, we have a return policy that ensures your satisfaction.  </p>
        <p class="red">What is your replacement policy?  </p>
        <p class="black">If you find something is missing, damaged, expired or doesn’t belong in your delivered order, please contact us within 3 days of receipt via email or our toll-free phone number, so that we may process any necessary corrections. We are committed to providing customers with a perfect delivery every time. </p>  
        <p class="red">What is your refund/return policy?  </p>
        <p class="black">There is no refund available for an already purchased product, except in cases where the stocks are unavailable and the customer refuses to accept alternative stock. However, the refund would have to be signed off only by the Merchandise team. 
In case you are not satisfied then please note that we would accept returns of merchandise in unused condition with original packaging. Also, note that for returning the goods you need to courier the item to the below address with proper packaging to avoid any in-transit damage:
<br>
<br>
<br>
Shipping Address: <br>
E-Commerce Division,<br>
Coffee Moon, 307/A New Friends Colony,New Delhi 110014<br>
Ph: 9650855090 <br>
The product has to be couriered only to the above address & can not be returned to any Cafe Coffee Day outlet.<br><br><br>


Kindly share the courier name & docket number after dispatch. Upon successful receipt of the courier & products found unused/undamaged, we would process a complete refund of the order value. Please note that the product should reach us in undamaged, unused & in a sale-able condition otherwise we would not be able to issue a refund. The return courier charges will have to be borne by the sender. </p>    
        </div>
    </body>
    <footer>
    <br>
    <br>
    <br>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="reservation.php">Reservation</a></td>
                <td><a href="shop.php">What's New</a></td>
                <td><a href="coffeepowder.php">Coffee Powder</a></td>
                <td><a href="ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href="delete.php">Cancel Reservation</a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="quickbites.php">Quick Bites</a></td>
                <td><a href="Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href="update.php">Update Reservation</a></td>
                <td><a href=""></a></td>
                <td><a href="tea.php">TEA's</a></td>
                <td><a href="Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="faq.php">FAQ</a></td>
                <td><a href="contact.php">Contact Us</a></td>
            </tr>
        </table> 
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>    
    </footer>
</html>