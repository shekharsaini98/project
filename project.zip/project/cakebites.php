<html>
    <head>
        <link rel="stylesheet" href="stylesheet.css">
    </head>
    <body>
        <div class="container">
            <nav>
                <ul>
                    <li> <img src="coffeemoon.png" class="logo"> </li>
                    <li> <a href="index.php">HOME</a> </li>
                    <li> <a href="reservation.php">RESERVATION</a> </li>
                    <li> <a href="blog.php">BLOG</a> </li>
                    <li> <a href="shop.php">SHOP</a> </li>
                    <li> <a href="contact.php">CONTACT</a> </li>
                    <input type="search"class="search" name="search" placeholder="Search..">
                </ul>
            </nav>
        </div>
        <div class="info">You can order our products by contacts</div> 
        <div class="shophead">
            <span id="categories">CATEGORIES</span>
            <span id="bests">CAKE BITES</span>
        </div> 
        <div class="shoplist">
            <ul>
                <li><a href="shop.php">WHAT'S NEW</a></li>
                <li><a href="coffeepowder.php">COFFEE POWDERS</a></li>
                <li><a href="tea.php">TEA</a></li>
                <li><a href="quickbites.php">QUICK BITES</a></li>
                <li><a href="cakebites.php">CAKE BITES</a></li>
            </ul>    
        </div>
        <div id="row">
            <div class="firstrow1">
                <label for="fsb">Pure Indulgence Cake (700gms)</label><br>
                <a href="buy/Pure Indulgence Cake (700gms).php"><img src="cakebites/pure_indulgence.jpg" id="fsb" alt="Pure Indulgence Cake (700gms)" title="Pure Indulgence Cake (700gms)"></a>
                <p>Rs.663/-</p>
            </div>
            <div class="firstrow2">
                <label for="hsg">Hazelnut Karat Celebration Cake (700gms)</label><br>
                <a href="buy/Hazelnut Karat Celebration Cake (700gms).php"><img src="cakebites/hazelnut_karat.jpg" id="hsg" alt="Hazelnut Karat Celebration Cake (700gms)" title="Hazelnut Karat Celebration Cake (700gms)"></a>
                <p>Rs.663/-</p>
            </div> 
        </div> 
    </body>
    <footer>
    <br>
    <br>
    <br>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="reservation.php">Reservation</a></td>
                <td><a href="shop.php">What's New</a></td>
                <td><a href="coffeepowder.php">Coffee Powder</a></td>
                <td><a href="ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href="delete.php">Cancel Reservation</a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="quickbites.php">Quick Bites</a></td>
                <td><a href="Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href="update.php">Update Reservation</a></td>
                <td><a href=""></a></td>
                <td><a href="tea.php">TEA's</a></td>
                <td><a href="Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="faq.php">FAQ</a></td>
                <td><a href="contact.php">Contact Us</a></td>
            </tr>
        </table> 
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>    
    </footer>
</html>        