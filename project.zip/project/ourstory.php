<html>
    <head>
        <link rel="stylesheet" href="stylesheet.css">
        
    </head>
    <body>
        <div class="container">
            <nav>
                <ul>
                    <li> <img src="coffeemoon.png" class="logo"> </li>
                    <li> <a href="index.php">HOME</a> </li>
                    <li> <a href="reservation.php">RESERVATION</a> </li>
                    <li> <a href="blog.php">BLOG</a> </li>
                    <li> <a href="shop.php">SHOP</a> </li>
                    <li> <a href="contact.php">CONTACT</a> </li>
                    <input type="search"class="search" name="search" placeholder="Search..">
                </ul>
            </nav>
        </div>
        <br>
        <div class="aboutusstory">
        <h3>ABOUT US</h3>
        <p>Coffee Moon, a part of Coffee Day Global Limited, is India’s favourite hangout for coffee and conversations. Popularly known as CM, we strive to provide the best experience to our guests. Our coffees are sourced from thousands of small coffee planters, who made us who we are today and we're glad to be a part of their lives. We opened our first cafe in 1996 at Brigade Road in Bangalore – the youth and the young at heart immediately took to the cafe, and it continues to be one of the most happening places in the city. CM to the youth is a “hangout” spot where they meet people, make conversations, and have a whole lot of fun over steaming cups of great coffee.It's been an exciting journey since then to becoming the largest organised retail cafe chain in the country. We’re also present in Austria, Czech Republic and Malaysia, so if your travel takes you there, do stop by our outlets to get a taste from back home!</p>
        </div>
    </body>
    <footer>
    <br>
    <br>
    <br>
        <hr>
        <br>
        <table>
            <tr>
                <th><a>Quick Links</a></th>
                <th><a>Cafe Menu</a></th>
                <th><a>Shop</a></th>
                <th><a>About Us</a></th>
            </tr> 
            <tr>
                <td><a href="reservation.php">Reservation</a></td>
                <td><a href="shop.php">What's New</a></td>
                <td><a href="coffeepowder.php">Coffee Powder</a></td>
                <td><a href="ourstory.php">Our Story</a></td>
            </tr> 
            <tr>
                <td><a href="delete.php">Cancel Reservation</a></td>
                <td><a href="">Nutritional Info</a></td>
                <td><a href="quickbites.php">Quick Bites</a></td>
                <td><a href="Foundation.php">Foundation</a></td>
            </tr>
            <tr>
                <td><a href="update.php">Update Reservation</a></td>
                <td><a href=""></a></td>
                <td><a href="tea.php">TEA's</a></td>
                <td><a href="Careers.php">Careers</a></td>
            </tr>
            <tr>
                <td><a href=""></a></td>
                <td><a href=""></a></td>
                <td><a href="faq.php">FAQ</a></td>
                <td><a href="contact.php">Contact Us</a></td>
            </tr>
        </table> 
        <br>
        <hr>  
        <p class="black">&copy;Coffee Moon. All rights reserved.</p>    
    </footer>
</html>